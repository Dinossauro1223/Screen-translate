"""
Captura de tela leve, usando mss (biblioteca em C por baixo, muito rápida
e sem dependência de GPU). Isso é o equivalente ao MediaProjection do Android
usado pelo app de celular.
"""
import numpy as np
import mss


class ScreenCapture:
    def __init__(self):
        self.sct = mss.mss()

    def grab(self, region):
        """
        region: tupla (x1, y1, x2, y2) em coordenadas absolutas da tela.
        Retorna um array numpy no formato BGRA (compatível com OpenCV/RapidOCR).
        """
        x1, y1, x2, y2 = region
        monitor = {
            "left": int(x1),
            "top": int(y1),
            "width": int(x2 - x1),
            "height": int(y2 - y1),
        }
        shot = self.sct.grab(monitor)
        img = np.array(shot)  # shape (H, W, 4) -> BGRA
        return img

    def close(self):
        self.sct.close()
