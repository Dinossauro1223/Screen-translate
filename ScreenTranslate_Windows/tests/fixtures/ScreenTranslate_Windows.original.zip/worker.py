"""
Thread de trabalho: roda o loop captura -> OCR -> tradução em background,
sem travar a interface. Só reprocessa quando a imagem da região realmente
muda (hash), pra não gastar CPU/à toa quando a tela está parada - o mesmo
tipo de otimização que apps mobile usam para durar mais bateria.
"""
import hashlib
import time

from PyQt5 import QtCore

from capture import ScreenCapture


class TranslateWorker(QtCore.QThread):
    blocks_ready = QtCore.pyqtSignal(list)

    def __init__(self, region, ocr, translator, interval=0.8,
                 context_refiner=None, history_size=5):
        super().__init__()
        self.region = region
        self.ocr = ocr
        self.translator = translator
        self.interval = interval
        self.context_refiner = context_refiner
        self.history_size = history_size

        self._running = True
        self._last_hash = None
        self._history = []
        self.capture = ScreenCapture()

    def run(self):
        while self._running:
            img = self.capture.grab(self.region)
            img_hash = hashlib.md5(img.tobytes()).hexdigest()

            if img_hash != self._last_hash:
                self._last_hash = img_hash
                self._process_frame(img)

            time.sleep(self.interval)

        self.capture.close()

    def _process_frame(self, img):
        raw_blocks = self.ocr.recognize(img)
        out_blocks = []

        for b in raw_blocks:
            if b["score"] < 0.5 or not b["text"].strip():
                continue

            x1, y1, x2, y2 = b["bbox"]
            abs_bbox = (
                self.region[0] + x1,
                self.region[1] + y1,
                self.region[0] + x2,
                self.region[1] + y2,
            )

            translated = self.translator.translate(b["text"])

            if self.context_refiner:
                translated = self.context_refiner.refine(
                    translated, b["text"], self._history
                )

            self._history.append(b["text"])
            self._history = self._history[-self.history_size:]

            out_blocks.append({"bbox": abs_bbox, "text": translated})

        self.blocks_ready.emit(out_blocks)

    def stop(self):
        self._running = False
        self.wait()
