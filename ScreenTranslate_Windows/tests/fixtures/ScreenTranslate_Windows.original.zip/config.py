"""
Configurações centrais do Screen Translate PC.
Ajuste aqui os idiomas e o comportamento do pipeline.
"""

# Idioma do texto que aparece na tela (o que a OCR vai ler)
SOURCE_LANG = "en"

# Idioma para o qual você quer traduzir
TARGET_LANG = "pt"

# Intervalo mínimo entre capturas de tela, em segundos.
# Quanto menor, mais "tempo real", mas mais uso de CPU.
CAPTURE_INTERVAL = 0.8

# Se True, tenta usar uma pequena IA local (GGUF via llama-cpp-python)
# para ajustar a tradução com base no contexto das últimas falas.
# Deixe False para começar: já funciona sem isso, e fica bem mais leve.
ENABLE_CONTEXT_AI = False

# Caminho do modelo GGUF (só é usado se ENABLE_CONTEXT_AI = True)
# Sugestões leves: Qwen2.5-0.5B-Instruct-GGUF ou Gemma-2-2b-it (quantizado Q4_K_M)
CONTEXT_MODEL_PATH = "models/qwen2.5-0.5b-instruct-q4_k_m.gguf"

# Quantas falas anteriores mandar como contexto para a IA local
CONTEXT_HISTORY_SIZE = 5

# Aparência do overlay
OVERLAY_FONT_FAMILY = "Noto Sans"
OVERLAY_FONT_SIZE = 12
OVERLAY_BG_COLOR = (0, 0, 0, 190)     # RGBA - fundo atrás do texto traduzido
OVERLAY_TEXT_COLOR = (255, 255, 255)  # RGB - cor do texto traduzido
