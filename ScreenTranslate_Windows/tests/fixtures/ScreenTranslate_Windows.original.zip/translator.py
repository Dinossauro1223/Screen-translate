"""
Tradução 100% local via Argos Translate (https://github.com/argosopentech/argos-translate).

Como funciona por baixo: motores de tradução neural (CTranslate2 + modelos
no formato OpenNMT), do mesmo jeito que o libtranslate_jni.so do APK usa
TensorFlow Lite + SentencePiece. A diferença é que aqui o "pacote de idioma"
fica em arquivos separados baixados uma vez (veja install_language_pack.py),
então o programa principal continua pequeno.

Instalação: pip install argostranslate
"""
import argostranslate.translate


class Translator:
    def __init__(self, source_lang="en", target_lang="pt"):
        self.source_lang = source_lang
        self.target_lang = target_lang
        self.translation = self._load_translation()

    def _load_translation(self):
        installed_languages = argostranslate.translate.get_installed_languages()
        from_lang = next((l for l in installed_languages if l.code == self.source_lang), None)
        to_lang = next((l for l in installed_languages if l.code == self.target_lang), None)

        if not from_lang or not to_lang:
            raise RuntimeError(
                f"Pacote de idioma '{self.source_lang}' -> '{self.target_lang}' não está instalado.\n"
                f"Rode: python install_language_pack.py {self.source_lang} {self.target_lang}"
            )
        return from_lang.get_translation(to_lang)

    def translate(self, text):
        text = text.strip()
        if not text:
            return ""
        return self.translation.translate(text)

    def translate_batch(self, texts):
        return [self.translate(t) for t in texts]
