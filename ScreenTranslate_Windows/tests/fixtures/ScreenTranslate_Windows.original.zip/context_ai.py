"""
Camada OPCIONAL de IA local para contextualizar a tradução.

A tradução "crua" do Argos Translate (translator.py) já funciona sozinha e é
rápida. Esta camada extra usa um modelo de linguagem pequeno, rodando
totalmente offline via llama-cpp-python, para reescrever a tradução levando
em conta as últimas falas - útil em mangás, jogos e diálogos onde uma frase
isolada fica ambígua sem contexto.

Modelos sugeridos (baixe o .gguf uma vez, com internet, e aponte
CONTEXT_MODEL_PATH em config.py para o arquivo):
- Qwen2.5-0.5B-Instruct-GGUF (quantizado Q4_K_M, ~400 MB, resposta quase instantânea em CPU)
- Gemma-2-2b-it-GGUF (quantizado Q4_K_M, ~1.6 GB, mais qualidade, um pouco mais lento)

Instalação: pip install llama-cpp-python
"""
from llama_cpp import Llama


class ContextRefiner:
    def __init__(self, model_path, n_ctx=2048, n_threads=4):
        self.llm = Llama(
            model_path=model_path,
            n_ctx=n_ctx,
            n_threads=n_threads,
            verbose=False,
        )

    def refine(self, raw_translation, original_text, context_lines):
        context_block = "\n".join(context_lines[-5:]) if context_lines else "(sem contexto anterior)"
        prompt = (
            "Você ajusta traduções automáticas para soarem naturais, usando o contexto da cena.\n"
            f"Contexto recente (falas anteriores):\n{context_block}\n\n"
            f"Texto original: {original_text}\n"
            f"Tradução automática: {raw_translation}\n\n"
            "Reescreva a tradução de forma natural e coerente com o contexto, "
            "mantendo o significado original. Responda apenas com a frase final, "
            "sem explicações e sem aspas."
        )
        out = self.llm(prompt, max_tokens=80, temperature=0.3, stop=["\n\n"])
        return out["choices"][0]["text"].strip()
