"""
Janela de overlay: transparente, sempre no topo, e "clique-através"
(não atrapalha o mouse/teclado do que está por baixo).

É o equivalente ao overlay de acessibilidade que o app de celular desenha
por cima de qualquer outro aplicativo.
"""
from PyQt5 import QtWidgets, QtGui, QtCore

import config


class OverlayWindow(QtWidgets.QWidget):
    def __init__(self, region):
        super().__init__()
        x1, y1, x2, y2 = region
        self.origin = (x1, y1)
        self.setGeometry(int(x1), int(y1), int(x2 - x1), int(y2 - y1))

        self.setWindowFlags(
            QtCore.Qt.FramelessWindowHint
            | QtCore.Qt.WindowStaysOnTopHint
            | QtCore.Qt.Tool
        )
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)

        self.blocks = []

    def update_blocks(self, blocks):
        """blocks: lista de {"bbox": (x1,y1,x2,y2) em coords absolutas da tela, "text": str}"""
        self.blocks = blocks
        self.update()

    def paintEvent(self, _event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        font = QtGui.QFont(config.OVERLAY_FONT_FAMILY, config.OVERLAY_FONT_SIZE)
        painter.setFont(font)

        ox, oy = self.origin
        bg_color = QtGui.QColor(*config.OVERLAY_BG_COLOR)
        text_color = QtGui.QColor(*config.OVERLAY_TEXT_COLOR)

        for block in self.blocks:
            x1, y1, x2, y2 = block["bbox"]
            rect = QtCore.QRectF(x1 - ox, y1 - oy, x2 - x1, y2 - y1)
            painter.fillRect(rect, bg_color)
            painter.setPen(text_color)
            painter.drawText(
                rect,
                QtCore.Qt.AlignCenter | QtCore.Qt.TextWordWrap,
                block["text"],
            )
