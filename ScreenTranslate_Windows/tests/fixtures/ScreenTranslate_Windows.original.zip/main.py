"""
Screen Translate PC - protótipo funcional
------------------------------------------
1) Ao rodar, arraste o mouse para marcar a área da tela que quer traduzir
   (ex: a janela do leitor de manga, do jogo, do PDF, etc.).
2) A tradução aparece por cima da área selecionada, atualizando sozinha
   sempre que o texto na tela muda.
3) Pressione a tecla ESC a qualquer momento para fechar tudo.

Rode com: python main.py
"""
import sys

from PyQt5 import QtWidgets, QtGui, QtCore

import config
from ocr_engine import OCREngine
from translator import Translator
from overlay import OverlayWindow
from worker import TranslateWorker


class RegionSelector(QtWidgets.QWidget):
    """Tela cheia semi-transparente para o usuário arrastar e marcar a área."""
    selected = QtCore.pyqtSignal(tuple)

    def __init__(self):
        super().__init__()
        screen_geo = QtWidgets.QApplication.primaryScreen().geometry()
        self.setGeometry(screen_geo)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        self.setWindowOpacity(0.25)
        self.setStyleSheet("background-color: black;")
        self.setCursor(QtCore.Qt.CrossCursor)

        self._start = None
        self._end = None

    def mousePressEvent(self, event):
        self._start = event.pos()
        self._end = event.pos()
        self.update()

    def mouseMoveEvent(self, event):
        self._end = event.pos()
        self.update()

    def mouseReleaseEvent(self, event):
        self._end = event.pos()
        x1, y1 = self._start.x(), self._start.y()
        x2, y2 = self._end.x(), self._end.y()
        region = (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))

        if region[2] - region[0] < 10 or region[3] - region[1] < 10:
            # área minúscula demais, ignora e deixa o usuário tentar de novo
            self._start = None
            self._end = None
            self.update()
            return

        self.selected.emit(region)
        self.close()

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            QtWidgets.QApplication.instance().quit()

    def paintEvent(self, _event):
        if self._start and self._end:
            painter = QtGui.QPainter(self)
            pen = QtGui.QPen(QtGui.QColor(255, 60, 60), 2)
            painter.setPen(pen)
            rect = QtCore.QRect(self._start, self._end)
            painter.drawRect(rect)


class App:
    def __init__(self):
        self.qt_app = QtWidgets.QApplication(sys.argv)
        self.worker = None
        self.overlay = None

    def start(self):
        print("Arraste o mouse para marcar a área da tela a traduzir...")
        print("(ESC a qualquer momento fecha o programa)")

        selector = RegionSelector()
        selector.selected.connect(self._on_region_selected)
        selector.show()

        return self.qt_app.exec_()

    def _on_region_selected(self, region):
        print(f"Área selecionada: {region}")
        print("Carregando OCR e tradutor (pode levar alguns segundos na primeira vez)...")

        ocr = OCREngine()
        translator = Translator(
            source_lang=config.SOURCE_LANG,
            target_lang=config.TARGET_LANG,
        )

        context_refiner = None
        if config.ENABLE_CONTEXT_AI:
            from context_ai import ContextRefiner
            context_refiner = ContextRefiner(config.CONTEXT_MODEL_PATH)

        self.overlay = OverlayWindow(region)
        self.overlay.show()

        self.worker = TranslateWorker(
            region=region,
            ocr=ocr,
            translator=translator,
            interval=config.CAPTURE_INTERVAL,
            context_refiner=context_refiner,
            history_size=config.CONTEXT_HISTORY_SIZE,
        )
        self.worker.blocks_ready.connect(self.overlay.update_blocks)
        self.worker.start()

        print("Tradução ao vivo ativa. Feche a janela do overlay ou mate o processo para parar.")


def main():
    try:
        app = App()
        sys.exit(app.start())
    except Exception as exc:
        # Como o launcher usa pythonw.exe, mostre erros em uma janela em vez
        # de deixar o usuário sem feedback caso algo falhe na inicialização.
        try:
            fallback = QtWidgets.QApplication.instance()
            if fallback is None:
                fallback = QtWidgets.QApplication(sys.argv)
            QtWidgets.QMessageBox.critical(
                None,
                "Screen Translate — erro",
                "Não foi possível iniciar o programa.\\n\\n"
                f"{type(exc).__name__}: {exc}",
            )
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    main()
