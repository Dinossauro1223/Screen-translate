"""
Motor de OCR local, via RapidOCR (https://github.com/RapidAI/RapidOCR).

Por que RapidOCR e não Tesseract puro:
- Roda em cima do ONNX Runtime (o mesmo tipo de motor que o TensorFlow Lite
  usado no app de celular) - modelos pequenos (poucos MB cada) e rápidos em CPU.
- Detecção + reconhecimento juntos (DBNet para achar as caixas de texto,
  CRNN para reconhecer os caracteres), assim como o pipeline do ML Kit no APK.
- Suporta multi-idioma trocando o modelo de reconhecimento (latim, chinês,
  japonês, coreano, etc.), do mesmo jeito que o app baixa modelos por idioma.

Instalação: pip install rapidocr-onnxruntime
"""
from rapidocr_onnxruntime import RapidOCR


class OCREngine:
    def __init__(self):
        self.ocr = RapidOCR()

    def recognize(self, img):
        """
        img: array numpy (BGRA ou BGR/RGB) vindo do ScreenCapture.
        Retorna uma lista de blocos: [{"bbox": (x1,y1,x2,y2), "text": str, "score": float}, ...]
        As coordenadas do bbox são relativas à própria imagem recortada (não à tela toda).
        """
        # RapidOCR espera BGR de 3 canais; se vier BGRA, descarta o canal alpha
        if img.shape[-1] == 4:
            img = img[:, :, :3]

        result, _elapse = self.ocr(img)

        blocks = []
        if result:
            for box, text, score in result:
                xs = [p[0] for p in box]
                ys = [p[1] for p in box]
                bbox = (min(xs), min(ys), max(xs), max(ys))
                blocks.append({"bbox": bbox, "text": text, "score": score})
        return blocks
