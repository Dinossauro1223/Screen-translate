"""
Baixa e instala um pacote de idioma do Argos Translate.

Isso só precisa de internet UMA VEZ, na hora de instalar o par de idiomas.
Depois disso, a tradução funciona 100% offline - exatamente como o app de
celular baixa o "pacote de idioma" separadamente e mantém o instalador
principal pequeno.

Uso:
    python install_language_pack.py en pt
    python install_language_pack.py ja pt
    python install_language_pack.py ko en
"""
import sys
import argostranslate.package


def install_pack(from_code, to_code):
    print("Atualizando índice de pacotes disponíveis...")
    argostranslate.package.update_package_index()
    available_packages = argostranslate.package.get_available_packages()

    pkg = next(
        (p for p in available_packages if p.from_code == from_code and p.to_code == to_code),
        None,
    )
    if pkg is None:
        raise RuntimeError(
            f"Não encontrei o par {from_code} -> {to_code} no índice do Argos Translate. "
            f"Verifique os códigos de idioma (ex: en, pt, ja, ko, zh, es)."
        )

    print(f"Baixando pacote {from_code} -> {to_code} ...")
    downloaded_path = pkg.download()
    argostranslate.package.install_from_path(downloaded_path)
    print(f"Pronto! Pacote {from_code} -> {to_code} instalado e pronto para uso offline.")


if __name__ == "__main__":
    from_code = sys.argv[1] if len(sys.argv) > 1 else "en"
    to_code = sys.argv[2] if len(sys.argv) > 2 else "pt"
    install_pack(from_code, to_code)
